# Vaim-sms
<img src="vaim-sms.png"><br>


- What is Vaim-sms ?
> This is sms bomber who send otp in target phone number unlimitly.
> Many times you just want to annoy or play a prank on your friends.
> If you find yourself in that situation then this SMS Bomber is the perfect tool for you!
> You can send unlimited SMS to anyone. This awesome app works with every operator/carrier.
> this tool made by @vaimpier_ritik

<br>

- Vaim-sms features 

* `Send unlimited messages all at one times.`

* `Supports newest Android also.`

* `Instant SMS delivery or chose a delay.`

* `Working with all Operators/Carriers.`

* `No missing SMS issues, all messages will be sent.`

<br>

- Support

> `termux and all linux os windows.etc..`

> `before update works only india.`

> `ffbonline.com and more threads.`
 
 <br>

- Installation & Step's
 
> `apt update && apt upgrade`
 
> `git clone https://github.com/VaimpierOfficial/Vaim-sms`
 
> `cd Vaim-sms`  
 
> `bash Vaim-sms.sh`

<br>


- <a href="https://www.youtube.com/watch?v=4s9DscS597g"> CLICK HERE AND SEE TUTORIAL </a>

